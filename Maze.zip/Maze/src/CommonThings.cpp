#include "CommonThings.h"

CommonThings::CommonThings()
{
    //ctor
}

CommonThings::~CommonThings()
{
    //dtor
}
